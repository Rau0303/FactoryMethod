import 'food.dart';

class GamBurger implements Food{
  @override
  void makeFood() {
    print('делаем гамбургер');
  }
  @override
  void putFood() {
    print('упаковаем гамбургер');
  }

}