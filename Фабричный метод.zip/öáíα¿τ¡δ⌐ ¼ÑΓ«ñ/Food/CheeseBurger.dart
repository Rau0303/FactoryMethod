import 'food.dart';

class CheeseBurger implements Food{
  @override
  void makeFood() {
    print('делаем чизбургер');
  }

  @override
  void putFood() {
    print('упаковаем чизбургер');
  }

}