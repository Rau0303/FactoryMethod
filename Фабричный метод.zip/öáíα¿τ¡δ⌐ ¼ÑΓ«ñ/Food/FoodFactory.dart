import 'CheeseBurger.dart';
import 'FishBurger.dart';
import 'GamBurger.dart';
import 'food.dart';

class FoodFactory{
  Food? createFood(String type){
    Food? food = null;

    switch (type) {
      case 'Гамбургер':
        Food food = new GamBurger();
        break;
      case 'Чизбургер':
        Food food = new CheeseBurger();
        break;
      case 'Рыбный бургер':
        Food food = new FishBurger();
        break;

    }
    return food;
  }
}