import 'food.dart';

class FishBurger implements Food{
  @override
  void makeFood() {
    print('делаем рыбный бургер');
  }

  @override
  void putFood() {
    print('упаковаем рыбный бургер');
  }
  

}