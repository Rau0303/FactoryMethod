class Food{
  void makeFood(){

  }
  void putFood(){

  }

}