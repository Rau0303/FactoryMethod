import 'Coffee/CoffeeFactory.dart';
import 'Coffee/coffee.dart';
import 'Drink/DrinkFactory.dart';
import 'Drink/drink.dart';
import 'Food/FoodFactory.dart';
import 'Food/food.dart';

class McDonalds{
  late final FoodFactory foodFactory;
  late final DrinkFactory drinkFactory;
  late final CoffeeFactory coffeeFactory;

  McDonalds(this.foodFactory,this.drinkFactory,this.coffeeFactory);

  Food? orderFood(String type){
    Food? food = foodFactory.createFood(type);
    food?.makeFood();
    food?.putFood();
    print('Вот ваш $type!');
    return food;
  }
  Drink? orderDrink(String type){
    Drink? drink = drinkFactory.createDrink(type);
    drink?.pourIntoCup();

    print('Вот ваш $type!');
    return drink;
  }

  Coffee? orderCoffee(String type){
    Coffee? coffee = coffeeFactory.createCoffee(type);
    coffee?.grindCoffee();
    coffee?.makeCoffee();
    coffee?.pourIntoCup();

    print('Вот ваш $type!');
    return coffee;
  }

  

}