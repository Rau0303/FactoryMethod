class Coffee{
  void grindCoffee(){
        // перемалываем кофе
  }
  void makeCoffee(){
        // делаем кофе
  }
  void pourIntoCup(){
        // наливаем в чашку
  }

}