import 'coffee.dart';

class Espresso implements Coffee{
  @override
  void grindCoffee() {
    print('перемалываем кофе Американо!');
  }

  @override
  void makeCoffee() {
    print('делаем кофе '); 
  }

  @override
  void pourIntoCup() {
    print('налифаем на чашку');
  }

}