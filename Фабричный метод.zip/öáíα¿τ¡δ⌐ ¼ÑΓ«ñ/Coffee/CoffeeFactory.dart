import 'Cappuccino.dart';
import 'americano.dart';
import 'coffee.dart';
import 'espresso.dart';

class CoffeeFactory{
  Coffee? createCoffee(String type){
    Coffee? coffee = null;
    switch(type){
      case 'Американо':
       Coffee coffee = new Americano();
       break;
      case 'Капучино':
       Coffee coffee = new Cappucciono();
       break;
      case 'Эспрессо':
       Coffee coffee = new Espresso();
       break;
    }

    return coffee;
  }
}