import 'Coffee/CoffeeFactory.dart';
import 'Drink/DrinkFactory.dart';
import 'Food/FoodFactory.dart';
import 'McDonalds.dart';


void main(List<String> args) {
  CoffeeFactory coffeeFactory = new CoffeeFactory();
  DrinkFactory drinkFactory = new DrinkFactory();
  FoodFactory foodFactory = new FoodFactory();
  McDonalds mcDonalds = new McDonalds(foodFactory,drinkFactory,coffeeFactory);
  //print(mcDonalds.orderCoffee('Американо'));
  print(mcDonalds.foodFactory.createFood('Чизбургер'));
  print(mcDonalds.drinkFactory.createDrink('Кола'));


}