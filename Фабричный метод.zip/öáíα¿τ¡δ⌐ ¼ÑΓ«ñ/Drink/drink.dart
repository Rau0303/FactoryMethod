class Drink{
  void pourIntoCup(){
        // наливаем в чашку
  }

}