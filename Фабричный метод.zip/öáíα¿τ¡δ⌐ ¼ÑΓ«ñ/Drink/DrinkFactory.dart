
import 'CocaCola.dart';
import 'Fanta.dart';
import 'Sprite.dart';
import 'drink.dart';

class DrinkFactory {
 Drink? createDrink(String type){
  Drink? drink = null;

  switch(type){
    case 'Кола':
    Drink drink = new CocaCola();
    break;
    case 'Фанта':
    Drink drink = new Fanta();
    break;
    case 'Спрайт':
    Drink drink = new Sprite();
    break;
  }
  return drink;
 }

  
}