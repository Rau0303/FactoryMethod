import 'drink.dart';

class Fanta implements Drink{
  @override
  void pourIntoCup() {
    print('налить фанту');
  }

}