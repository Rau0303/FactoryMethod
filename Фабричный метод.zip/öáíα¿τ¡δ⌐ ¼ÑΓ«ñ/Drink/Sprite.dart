 import 'drink.dart';

class Sprite implements Drink{
  @override
  void pourIntoCup() {
    print('налить фанту');
  }

}