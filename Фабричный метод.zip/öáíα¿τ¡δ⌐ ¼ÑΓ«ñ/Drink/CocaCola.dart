import 'drink.dart';

class CocaCola implements Drink{
  @override
  void pourIntoCup() {
    print('налить колу');
  }

}